import Leaderboard from "@/components/stream/leaderboard";

export default function Home() {
  return <Leaderboard />;
}